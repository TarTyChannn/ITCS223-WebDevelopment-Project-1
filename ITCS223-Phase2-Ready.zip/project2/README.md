# Long Gone — Haunted House Real Estate
**ITCS223 Introduction to Web Development — Project Phase II**
Section 2, Group 3

---

## Team Members
| Name | Student ID |
|---|---|
| Adisorn Vechkultumrong | 6788142 |
| Rachen Chaothai | 6788186 |
| Chavanon Opaspakkthon | 6788202 |
| Chindanai Panitponkang | 6788203 |

---

## Project Overview
Long Gone is a haunted house real estate platform where users can search for, view, buy, and rent properties. Administrators can manage listings through a dedicated dashboard. The system is split into a **front-end server** (port 5000) and a **web service server** (port 3000), both powered by Node.js.

---

## Prerequisites
- **Node.js** v18 or higher
- **MySQL** 8.0 or higher
- **npm** (comes with Node.js)

---

## Step 1 — Set Up the Database

1. Open MySQL and create the database:
   ```sql
   CREATE DATABASE longgone;
   ```

2. Import the SQL file:
   ```bash
   mysql -u root -p longgone < sec2_gr3_database.sql
   ```
   Enter your MySQL root password when prompted.

---

## Step 2 — Configure the Web Service

1. Navigate into the web service folder:
   ```bash
   cd sec2_gr3_ws_src
   ```

2. Create a `.env` file (copy the example below):
   ```
   HOST=localhost
   DB_USER=root
   DB_PASS=your_mysql_password
   DB_NAME=longgone
   PORT=3000
   ```

3. Install dependencies:
   ```bash
   npm install
   ```

4. Start the web service:
   ```bash
   node app.js
   ```
   You should see: `Server listening on port: 3000`

---

## Step 3 — Configure the Front-End Server

Open a **new terminal window/tab**.

1. Navigate into the front-end folder:
   ```bash
   cd sec2_gr3_fe_src
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the front-end server:
   ```bash
   node server.js
   ```
   You should see: `Server listening on port: 5000`

---

## Step 4 — Open the App

Open your browser and go to:
```
http://localhost:5000
```

---

## Admin Login
Use an AdminID and Password from the `Admin` table in the database.
The login page calls the Authentication Web Service (`POST /admin/login`) to verify credentials.

---

## Web Service API Endpoints

| Method | URL | Description |
|---|---|---|
| GET | `/houses/search` | Search all houses (optional: `?category=&rating=&location=`) |
| GET | `/houses/:id` | Get single house by HouseID |
| POST | `/houses` | Add a new house (admin) |
| PUT | `/houses/:id` | Update a house (admin) |
| DELETE | `/houses/:id` | Delete a house (admin) |
| POST | `/admin/login` | Authenticate an admin |
| POST | `/admin/register` | Register a new admin |

---

## Public Web Service
The house detail page embeds **Google Maps** to show the property's location using the free Google Maps iframe embed (no API key required).

---

## Notes & Remarks
- The front-end (`port 5000`) and web service (`port 3000`) **must both be running** at the same time.
- If your MySQL password contains special characters, wrap it in quotes in the `.env` file.
- The web service URL in `script.js` is set to `http://localhost:3000`. If you deploy to a different host, update the `WS_BASE` variable at the top of `sec2_gr3_fe_src/script.js`.
- There are no known bugs. The app falls back gracefully with an error message if the web service is unreachable.

---

## Project Structure
```
├── README.md
├── sec2_gr3_database.sql       ← MySQL database dump
├── sec2_gr3_fe_src/            ← Front-end server (port 5000)
│   ├── server.js               ← Express static server
│   ├── script.js               ← Shared API client (Fetch API)
│   ├── html/                   ← All HTML pages + CSS
│   └── images/                 ← Team member photos
└── sec2_gr3_ws_src/            ← Web service server (port 3000)
    ├── app.js                  ← All REST API routes + MySQL queries
    └── .env                    ← Database credentials (you create this)
```
