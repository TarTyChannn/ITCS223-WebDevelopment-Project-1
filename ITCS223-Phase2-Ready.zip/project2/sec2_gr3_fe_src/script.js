// LONG GONE — API CLIENT
// All data comes from the back-end web service at WS_BASE.
// Change WS_BASE if your web service runs on a different port/host.
var WS_BASE = 'http://localhost:3000';

// ── Public API ──────────────────────────────────────────────────────────────

var LG = {

    // Search houses with optional criteria
    // params: { category, rating, location }  — all optional
    search: async function(params) {
        var qs = new URLSearchParams();
        if (params && params.category && params.category !== 'all') qs.set('category', params.category);
        if (params && params.rating  && params.rating  !== '0')    qs.set('rating',   params.rating);
        if (params && params.location && params.location.trim())    qs.set('location', params.location.trim());
        var url = WS_BASE + '/houses/search' + (qs.toString() ? '?' + qs : '');
        var res = await fetch(url);
        if (!res.ok) throw new Error('Search failed: ' + res.status);
        var json = await res.json();
        return json.data;   // array of house objects
    },

    // Fetch a single house by HouseID (string like "H0000000001")
    getById: async function(id) {
        var res = await fetch(WS_BASE + '/houses/' + encodeURIComponent(id));
        if (!res.ok) return null;
        var json = await res.json();
        return json.data || null;
    },

    // Insert a new house (admin only)
    add: async function(house) {
        var res = await fetch(WS_BASE + '/houses', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(house)
        });
        var json = await res.json();
        if (!res.ok) throw new Error(json.error || 'Insert failed');
        return json;
    },

    // Update a house (admin only)
    update: async function(id, patch) {
        var res = await fetch(WS_BASE + '/houses/' + encodeURIComponent(id), {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(patch)
        });
        var json = await res.json();
        if (!res.ok) throw new Error(json.error || 'Update failed');
        return json;
    },

    // Delete a house (admin only)
    remove: async function(id) {
        var res = await fetch(WS_BASE + '/houses/' + encodeURIComponent(id), {
            method: 'DELETE'
        });
        var json = await res.json();
        if (!res.ok) throw new Error(json.error || 'Delete failed');
        return json;
    }
};

// ── Admin Auth ──────────────────────────────────────────────────────────────

// Login via the authentication web service
async function doApiLogin(adminId, password) {
    var res = await fetch(WS_BASE + '/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ AdminID: adminId, Password: password })
    });
    var json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Login failed');
    return json.admin;  // admin info object
}

function isAdmin() {
    if (localStorage.getItem('lgAdmin') === 'true') {
        sessionStorage.setItem('lgAdmin', 'true');
        sessionStorage.setItem('lgAdminUser', localStorage.getItem('lgAdminUser') || 'Admin');
    }
    return sessionStorage.getItem('lgAdmin') === 'true';
}

function getAdminUser() {
    return sessionStorage.getItem('lgAdminUser') || localStorage.getItem('lgAdminUser') || 'Admin';
}

function doLogout() {
    sessionStorage.removeItem('lgAdmin');
    localStorage.removeItem('lgAdmin');
    sessionStorage.removeItem('lgAdminUser');
    localStorage.removeItem('lgAdminUser');
    location.href = '/admin/login';
}

// ── UI Utilities ─────────────────────────────────────────────────────────────

function showToast(msg, color) {
    var existing = document.querySelector('.toast');
    if (existing) existing.remove();
    var t = document.createElement('div');
    t.className = 'toast';
    t.style.background = color || '#2e9e5e';
    t.innerHTML = msg;
    document.body.appendChild(t);
    setTimeout(function() {
        t.style.opacity = '0';
        t.style.transform = 'translateY(20px)';
        t.style.transition = 'all .3s';
    }, 2200);
    setTimeout(function() { t.remove(); }, 2600);
}

function updateNavAdmin() {
    var btn = document.getElementById('adminBtn');
    var ind = document.getElementById('adminIndicator');
    if (!btn && !ind) return;
    if (isAdmin()) {
        var user = sessionStorage.getItem('lgAdminUser') || localStorage.getItem('lgAdminUser') || 'Admin';
        if (btn) {
            btn.textContent = 'Dashboard';
            btn.onclick = function() { location.href = '/admin/dashboard'; };
        }
        if (ind) {
            ind.style.display = 'inline';
            ind.innerHTML = '&#128274; ' + user;
        }
    } else {
        if (btn) {
            btn.onclick = function() { location.href = '/admin/login'; };
        }
        if (ind) {
            ind.style.display = 'none';
        }
    }
}

// Helper: map DB row → display-friendly object
function mapHouse(h) {
    return {
        id:         h.HouseID,
        name:       h.HouseName,
        price:      Number(h.HousePrice).toLocaleString(),
        priceRaw:   h.HousePrice,
        area:       h.HAreaName || '—',
        city:       (h.HAreaName || '').split(',')[0].trim(),
        location:   h.HAreaName || '—',
        type:       (h.CategoryName || 'buy').toLowerCase().includes('rent') ? 'rent' : 'buy',
        category:   h.CategoryName || '—',
        rating:     Math.round(parseFloat(h.avgRating) || 0),
        bedrooms:   h.bedroomCount  || 0,
        bathrooms:  h.bathroomCount || 0,
        basement:   h.basementCount || 0,
        desc:       h.Description   || '—',
        card:       h.PhotoURL || ('https://picsum.photos/seed/house' + h.HouseID + '/400/300'),
        imgs:       h.Photos  || [h.PhotoURL || ('https://picsum.photos/seed/house' + h.HouseID + '/900/600')]
    };
}

document.addEventListener('DOMContentLoaded', updateNavAdmin);
