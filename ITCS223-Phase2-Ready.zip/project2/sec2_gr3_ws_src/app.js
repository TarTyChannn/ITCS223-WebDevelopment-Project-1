const express  = require("express")
const mysql    = require("mysql2")
const path     = require('path')
const dotenv   = require("dotenv")
dotenv.config()

const dbConn = mysql.createConnection({
  host:     process.env.HOST,
  user:     process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME
})

dbConn.connect(function(err) {
  if (err) throw err;
  console.log(`Connected DB: ${process.env.DB_NAME}`)
})

const app    = express()
var cors     = require('cors');
app.use(cors())
const router = express.Router()
app.use(router)
router.use(express.json())
router.use(express.urlencoded({ extended: true }))

// ------------------------------------------------------------
// 1. SEARCH SERVICE
//    GET /houses/search?category=&rating=&location=
//    - No params  → returns all houses
//    - category   : HouseCategory.CategoryName  (optional)
//    - rating     : minimum average rating value (optional)
//    - location   : partial match on HAreaName   (optional)
//
//    Test case 1:
//      method: GET
//      URL: http://localhost:3000/houses/search?category=Mansion&location=Bangkok
//      expected: 200 JSON with matching houses
//
//    Test case 2:
//      method: GET
//      URL: http://localhost:3000/houses/search?rating=4&location=Chiang
//      expected: 200 JSON with houses rated 4+ in Chiang areas
// ------------------------------------------------------------
router.get('/houses/search', function(req, res) {
  const { category, rating, location } = req.query

  let sql = `
    SELECT
      h.HouseID, h.HouseName, h.BuyingPrice AS HousePrice,
      h.bedroomCount, h.bathroomCount, h.basementCount,
      h.Description, h.HAreaName,
      hc.CategoryName,
      AVG(r.RatingValue) AS avgRating,
      MIN(p.PhotoRef)    AS PhotoURL
    FROM House h
    LEFT JOIN HouseCategory hc ON h.HcategoryID = hc.categoryID
    LEFT JOIN Area a           ON h.HAreaName   = a.AreaName
    LEFT JOIN Rating r         ON h.HouseID     = r.RHouseID
    LEFT JOIN Photo p          ON h.HouseID     = p.PHouseID
    WHERE 1=1
  `
  const params = []

  if (category) {
    sql += ` AND hc.CategoryName = ?`
    params.push(category)
  }

  if (location) {
    sql += ` AND (
      h.HAreaName   LIKE ? OR
      a.AreaName    LIKE ? OR
      a.Province    LIKE ? OR
      a.District    LIKE ? OR
      a.Subdistrict LIKE ? OR
      a.Zipcode     LIKE ?
    )`
    const like = `%${location}%`
    params.push(like, like, like, like, like, like)
  }

  sql += ` GROUP BY h.HouseID`

  if (rating) {
    sql += ` HAVING avgRating >= ?`
    params.push(parseFloat(rating))
  }

  dbConn.query(sql, params, function(err, results) {
    if (err) return res.status(500).json({ error: err.message })
    res.json({ count: results.length, data: results })
  })
})

// ------------------------------------------------------------
// 2. GET SINGLE HOUSE BY ID (with all photos)
//    GET /houses/:id
//
//    Test case 1:
//      method: GET
//      URL: http://localhost:3000/houses/H0000000001
//      expected: 200 JSON with full house detail + photos array
//
//    Test case 2:
//      method: GET
//      URL: http://localhost:3000/houses/NOTEXIST
//      expected: 404 { "error": "House not found." }
// ------------------------------------------------------------
router.get('/houses/:id', function(req, res) {
  const { id } = req.params

  const sql = `
    SELECT
      h.HouseID, h.HouseName, h.BuyingPrice AS HousePrice,
      h.bedroomCount, h.bathroomCount, h.basementCount,
      h.Description, h.HAreaName,
      hc.CategoryName,
      AVG(r.RatingValue) AS avgRating
    FROM House h
    LEFT JOIN HouseCategory hc ON h.HcategoryID = hc.categoryID
    LEFT JOIN Rating r         ON h.HouseID     = r.RHouseID
    WHERE h.HouseID = ?
    GROUP BY h.HouseID
  `
  dbConn.query(sql, [id], function(err, results) {
    if (err) return res.status(500).json({ error: err.message })
    if (!results.length) return res.status(404).json({ error: 'House not found.' })

    const house = results[0]

    // Fetch all photos for this house
    dbConn.query('SELECT PhotoRef AS PhotoURL FROM Photo WHERE PHouseID = ?', [id], function(err2, photos) {
      if (err2) return res.status(500).json({ error: err2.message })
      house.Photos = photos.map(function(p) { return p.PhotoURL })
      res.json({ data: house })
    })
  })
})

// ------------------------------------------------------------
// 3. INSERT HOUSE (Admin only)
//    POST /houses
//    Body: { HouseID, HouseName, HousePrice, bedroomCount,
//            bathroomCount, basementCount, Description,
//            HcategoryID, HAreaName }
//
//    Test case 1:
//      method: POST
//      URL: http://localhost:3000/houses
//      body: raw JSON
//      {
//        "HouseID": "H9999999999",
//        "HouseName": "Test Manor",
//        "HousePrice": 100000,
//        "bedroomCount": 2,
//        "bathroomCount": 1,
//        "basementCount": 0,
//        "HcategoryID": 1,
//        "HAreaName": "Bangkok"
//      }
//      expected: 201 { "message": "House inserted successfully.", "HouseID": "H9999999999" }
//
//    Test case 2:
//      method: POST
//      URL: http://localhost:3000/houses
//      body: raw JSON  { "HouseName": "Missing ID House" }
//      expected: 400 { "error": "Missing required fields." }
// ------------------------------------------------------------
router.post('/houses', function(req, res) {
  const {
    HouseID, HouseName, HousePrice,
    bedroomCount, bathroomCount, basementCount,
    Description, HcategoryID, HAreaName
  } = req.body

  if (!HouseID || !HouseName || HousePrice === undefined ||
      bedroomCount === undefined || bathroomCount === undefined ||
      basementCount === undefined || !HcategoryID || !HAreaName) {
    return res.status(400).json({ error: 'Missing required fields.' })
  }

  const sql = `
    INSERT INTO House
      (HouseID, HouseName, BuyingPrice, bedroomCount, bathroomCount,
       basementCount, Description, HcategoryID, HAreaName)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `
  const params = [
    HouseID, HouseName, HousePrice,
    bedroomCount, bathroomCount, basementCount,
    Description || null, HcategoryID, HAreaName
  ]

  dbConn.query(sql, params, function(err) {
    if (err) return res.status(500).json({ error: err.message })
    res.status(201).json({ message: 'House inserted successfully.', HouseID })
  })
})

// ------------------------------------------------------------
// 4. UPDATE HOUSE (Admin only)
//    PUT /houses/:id
//    Body: any subset of { HouseName, HousePrice, bedroomCount,
//          bathroomCount, basementCount, Description,
//          HcategoryID, HAreaName }
//
//    Test case 1:
//      method: PUT
//      URL: http://localhost:3000/houses/H0000000001
//      body: raw JSON  { "HousePrice": 3500000 }
//      expected: 200 { "message": "House updated successfully.", "HouseID": "H0000000001" }
//
//    Test case 2:
//      method: PUT
//      URL: http://localhost:3000/houses/NOTEXIST
//      body: raw JSON  { "HouseName": "Ghost Mansion" }
//      expected: 404 { "error": "House 'NOTEXIST' not found." }
// ------------------------------------------------------------
router.put('/houses/:id', function(req, res) {
  const { id } = req.params
  const fields  = req.body
  const allowed = [
    'HouseName','BuyingPrice','bedroomCount','bathroomCount',
    'basementCount','Description','HcategoryID','HAreaName'
  ]

  const updates = []
  const params  = []

  allowed.forEach(function(field) {
    if (fields[field] !== undefined) {
      updates.push(`${field} = ?`)
      params.push(fields[field])
    }
  })

  if (updates.length === 0) {
    return res.status(400).json({ error: 'No valid fields provided for update.' })
  }

  params.push(id)
  const sql = `UPDATE House SET ${updates.join(', ')} WHERE HouseID = ?`

  dbConn.query(sql, params, function(err, result) {
    if (err) return res.status(500).json({ error: err.message })
    if (result.affectedRows === 0)
      return res.status(404).json({ error: `House '${id}' not found.` })
    res.json({ message: 'House updated successfully.', HouseID: id })
  })
})

// ------------------------------------------------------------
// 5. DELETE HOUSE (Admin only)
//    DELETE /houses/:id
//
//    Test case 1:
//      method: DELETE
//      URL: http://localhost:3000/houses/H0000000001
//      expected: 200 { "message": "House deleted successfully.", "HouseID": "H0000000001" }
//
//    Test case 2:
//      method: DELETE
//      URL: http://localhost:3000/houses/NOTEXIST
//      expected: 404 { "error": "House 'NOTEXIST' not found." }
// ------------------------------------------------------------
router.delete('/houses/:id', function(req, res) {
  const { id } = req.params

  dbConn.query('DELETE FROM House WHERE HouseID = ?', [id], function(err, result) {
    if (err) return res.status(500).json({ error: err.message })
    if (result.affectedRows === 0)
      return res.status(404).json({ error: `House '${id}' not found.` })
    res.json({ message: 'House deleted successfully.', HouseID: id })
  })
})

// ------------------------------------------------------------
// 6. ADMIN REGISTER
//    POST /admin/register
//    Body: { AdminID, Aname, AdminGmail, AdminPhoneNumber, Salary, Password }
//
//    Test case 1:
//      method: POST
//      URL: http://localhost:3000/admin/register
//      body: raw JSON
//      {
//        "AdminID": "ADM99",
//        "Aname": "Test Admin",
//        "AdminGmail": "test@longgone.th",
//        "AdminPhoneNumber": "081-000-0000",
//        "Salary": 30000,
//        "Password": "secret123"
//      }
//      expected: 201 { "message": "Admin registered successfully.", "AdminID": "ADM99" }
//
//    Test case 2:
//      method: POST
//      URL: http://localhost:3000/admin/register
//      body: raw JSON  { "AdminID": "ADM99", "Aname": "Dup Admin" }  (duplicate + missing fields)
//      expected: 400 or 409
// ------------------------------------------------------------
router.post('/admin/register', function(req, res) {
  const { AdminID, Aname, AdminGmail, AdminPhoneNumber, Salary, Password } = req.body

  if (!AdminID || !Aname || !AdminGmail || !AdminPhoneNumber || !Salary || !Password) {
    return res.status(400).json({ error: 'Missing required fields.' })
  }

  const sql = `
    INSERT INTO Admin (AdminID, Aname, AdminGmail, AdminPhoneNumber, Salary, Password)
    VALUES (?, ?, ?, ?, ?, ?)
  `
  dbConn.query(sql, [AdminID, Aname, AdminGmail, AdminPhoneNumber, Salary, Password], function(err) {
    if (err) {
      if (err.code === 'ER_DUP_ENTRY')
        return res.status(409).json({ error: `AdminID '${AdminID}' already exists.` })
      return res.status(500).json({ error: err.message })
    }
    res.status(201).json({ message: 'Admin registered successfully.', AdminID })
  })
})

// ------------------------------------------------------------
// 7. ADMIN LOGIN (Authentication Service)
//    POST /admin/login
//    Body: { AdminID, Password }
//
//    Test case 1:
//      method: POST
//      URL: http://localhost:3000/admin/login
//      body: raw JSON  { "AdminID": "ADM001", "Password": "correct_password" }
//      expected: 200 { "message": "Login successful.", "admin": { ... } }
//
//    Test case 2:
//      method: POST
//      URL: http://localhost:3000/admin/login
//      body: raw JSON  { "AdminID": "ADM001", "Password": "wrong_password" }
//      expected: 401 { "error": "Invalid AdminID or password." }
// ------------------------------------------------------------
router.post('/admin/login', function(req, res) {
  const { AdminID, Password } = req.body

  if (!AdminID || !Password) {
    return res.status(400).json({ error: 'AdminID and Password are required.' })
  }

  const sql = `SELECT AdminID, Aname, AdminGmail, AdminPhoneNumber, Salary, Password
               FROM Admin WHERE AdminID = ?`

  dbConn.query(sql, [AdminID], function(err, results) {
    if (err) return res.status(500).json({ error: err.message })

    if (results.length === 0)
      return res.status(401).json({ error: 'Invalid AdminID or password.' })

    const admin = results[0]

    if (Password !== admin.Password)
      return res.status(401).json({ error: 'Invalid AdminID or password.' })

    // Return admin info excluding password
    const { Password: _, ...adminInfo } = admin
    res.json({ message: 'Login successful.', admin: adminInfo })
  })
})

app.listen(process.env.PORT, function() {
  console.log(`Server listening on port: ${process.env.PORT}`)
})
